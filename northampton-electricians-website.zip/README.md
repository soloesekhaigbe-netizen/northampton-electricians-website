# Northampton Electricians — Static Site

A self-contained, single-page static website. **No build step. No dependencies.** Just three files.

```
static-export/
├── index.html      ← markup, SEO meta, JSON-LD
├── styles.css      ← custom CSS (animations, hero grid, toast)
├── app.js          ← icons, mobile menu, scroll reveal, form handler
└── _headers        ← Cloudflare Pages caching/security headers (optional)
```

External resources are loaded from CDN at runtime:
- **Tailwind CSS** (Play CDN) for utility classes
- **Google Fonts** (Outfit, Inter)
- **Lucide** icons

## Local preview

Just open `index.html` in a browser, or serve the folder:

```bash
cd static-export
python3 -m http.server 8080
# → http://localhost:8080
```

## Deploy to Cloudflare Pages

### Option A — Direct upload (fastest)
1. Go to https://dash.cloudflare.com → **Workers & Pages** → **Create application** → **Pages** → **Upload assets**.
2. Drag-and-drop the `static-export` folder (or zip it first and upload the zip).
3. Pick a project name, click **Deploy site**. Done — you'll get a `*.pages.dev` URL within seconds.

### Option B — Git integration
1. Push this folder to a GitHub/GitLab repo (the contents of `static-export/` should be at the repo root, or set the build output directory accordingly).
2. Cloudflare Pages → **Connect to Git** → select the repo.
3. Build settings:
   - **Framework preset:** None
   - **Build command:** *(leave blank)*
   - **Build output directory:** `/` (or `static-export` if you keep it nested)
4. Save and deploy. Subsequent pushes auto-deploy.

### Option C — Wrangler CLI
```bash
npm i -g wrangler
cd static-export
wrangler pages deploy . --project-name=northampton-electricians
```

### Custom domain
In the Pages project → **Custom domains** → add your domain (e.g. `northamptonelectricians.co.uk`). Cloudflare handles SSL automatically.

## Quote form: choose your backend

The form's default behaviour opens the visitor's email client with a pre-filled message (works with zero setup). To collect submissions automatically, edit `submitQuote()` in `app.js` — there are ready-to-uncomment snippets for:

- **Formspree** — https://formspree.io (free tier, ~50/month). Sign up, create a form, paste its ID.
- **Web3Forms** — https://web3forms.com (free, generous quota). Just needs an access key.
- **Cloudflare Pages Functions** — write `functions/api/quote.js` and POST from the form. This keeps everything inside Cloudflare.

Example Cloudflare Pages Function (optional):
```js
// functions/api/quote.js
export async function onRequestPost({ request, env }) {
  const data = await request.json();
  // forward to email service, KV, D1, or Resend, etc.
  return new Response(JSON.stringify({ ok: true }), { headers: { "Content-Type": "application/json" }});
}
```

## Customising
- **Phone number / address / hours** → edit the relevant strings in `index.html`.
- **Services list** → edit the `SERVICES` array near the top of `app.js`.
- **Why-Us / Reviews** → edit `WHY` and `REVIEWS` in `app.js`.
- **Brand colours** → adjust the `tailwind.config` block near the top of `index.html` and the CSS variables in `styles.css`.

## Production tip
Tailwind via the Play CDN is fine for small sites and is the simplest path. If you want a smaller, faster bundle, run Tailwind CLI once locally to generate a purged `tailwind.css` and replace the CDN script tag with `<link rel="stylesheet" href="./tailwind.css">`.

```bash
npx tailwindcss@latest -i ./input.css -o ./tailwind.css --minify
```
